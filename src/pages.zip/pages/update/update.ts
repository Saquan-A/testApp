import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-update',
  templateUrl: 'update.html',

})

export class UpdatePage{

}
